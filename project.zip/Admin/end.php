</div>
    </div>
<!-- partial -->

  <script  src="CSS/script.js"></script>

</body>
</html>