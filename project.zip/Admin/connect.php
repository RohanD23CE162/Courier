<?php 

$con=mysqli_connect("localhost","root");
$db=mysqli_select_db($con,"id20323457_courier123");

?>